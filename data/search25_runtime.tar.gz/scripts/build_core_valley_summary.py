#!/usr/bin/env python3
from __future__ import annotations
import argparse,collections,json
from pathlib import Path

def load(p):return json.loads(p.read_text())
def rows(p):return [json.loads(s) for s in p.read_text().splitlines() if s.strip()] if p.exists() else []
def key(r):
 return json.dumps(r.get('vertices_q') or r.get('vertices2') or r.get('vertices'),sort_keys=True,separators=(',',':'))
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--input',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);ap.add_argument('--expected-shards',type=int,default=20);ap.add_argument('--strict',action='store_true');a=ap.parse_args();a.out.mkdir(parents=True,exist_ok=True)
 stats={};bests=[];ordinary=[];valley=[];diags=[]
 for p in a.input.rglob('search_stats_*.json'):
  r=load(p);stats[int(r['shard'])]=r
 for p in a.input.rglob('best_trail_*.json'):bests.append(load(p))
 for p in a.input.rglob('verified_62plus_*.jsonl'):ordinary+=rows(p)
 for p in a.input.rglob('corebroken_valley_*.jsonl'):valley+=rows(p)
 for p in a.input.rglob('paired_diagnostics_*.json'):diags.append(load(p))
 received=sorted(stats);missing=[i for i in range(a.expected_shards) if i not in stats]
 if a.strict and missing:raise SystemExit(f'missing shards {missing}')
 if not bests:raise SystemExit('no bests')
 best=max(bests,key=lambda r:(int(r['covered_count']),-int(r.get('common17_overlap',99))))
 def dedup(xs):
  d={}
  for r in xs:d.setdefault(key(r),r)
  return list(d.values())
 ordinary=dedup([r for r in ordinary if int(r['covered_count'])>=62]);valley=dedup(valley)
 hist=collections.Counter(int(r['covered_count']) for r in bests+ordinary)
 mode=collections.defaultdict(lambda:{'shards':0,'attempts':0,'best':0,'min_common17':99,'finite_realizations':0})
 for r in stats.values():
  m=mode[r['mode']];m['shards']+=1;m['attempts']+=int(r.get('attempts',0));m['best']=max(m['best'],int(r.get('best_covered',0)));m['min_common17']=min(m['min_common17'],int(r.get('min_common17_overlap',99)));m['finite_realizations']+=int(r.get('finite_realizations',0))
 success63=sum(int(r['covered_count'])>=63 for r in ordinary+bests);success64=sum(int(r['covered_count'])>=64 for r in ordinary+bests)
 summary={'schema':'search25-run-summary-v1','strict':a.strict,'complete':not missing,'expected_shards':a.expected_shards,'received_shards':received,'missing_shards':missing,'best_covered':int(best['covered_count']),'best_candidate_id':best.get('candidate_id'),'ordered_63plus':success63,'ordered_64':success64,'attempts':sum(int(r.get('attempts',0)) for r in stats.values()),'finite_realizations':sum(int(r.get('finite_realizations',0)) for r in stats.values()),'min_common17_overlap':min(int(r.get('min_common17_overlap',99)) for r in stats.values()),'ordinary_62plus_rows':len(ordinary),'corebroken_valley_rows':len(valley),'mode_breakdown':dict(mode)}
 (a.out/'run_summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n');(a.out/'best_candidate.json').write_text(json.dumps(best,indent=2,sort_keys=True)+'\n')
 (a.out/'coverage_histogram.json').write_text(json.dumps({str(k):v for k,v in sorted(hist.items())},indent=2)+'\n')
 (a.out/'mode_breakdown.json').write_text(json.dumps(dict(mode),indent=2,sort_keys=True)+'\n')
 (a.out/'exact_verification_report.json').write_text(json.dumps({'schema':'search25-exact-verification-report-v1','dual_verifiers_required':True,'received_shards':received,'best_covered':summary['best_covered'],'ordered_63plus':success63,'ordered_64':success64},indent=2)+'\n')
 with (a.out/'ordinary_candidate_additions.jsonl').open('w') as f:
  for r in sorted(ordinary,key=lambda r:int(r['covered_count']),reverse=True):f.write(json.dumps(r,separators=(',',':'))+'\n')
 with (a.out/'corebroken_valley_bank.jsonl').open('w') as f:
  for r in valley:f.write(json.dumps(r,separators=(',',':'))+'\n')
 md=f'''# smart-search-25-core-valley result\n\n- strict complete: `{not missing}` (`{len(received)}/{a.expected_shards}` shards)\n- best ordered finite trail: `{summary['best_covered']}/64`\n- ordered `63/64+`: `{success63}`\n- ordered `64/64`: `{success64}`\n- atomic paired attempts: `{summary['attempts']}`\n- finite contact-span realizations: `{summary['finite_realizations']}`\n- minimum common-17 overlap reached: `{summary['min_common17_overlap']}`\n- saved new `62/64+`: `{len(ordinary)}`\n- saved core-broken valley states: `{len(valley)}`\n\nAn unordered line cover or Hamiltonian support graph is not counted as a trail.\n'''
 (a.out/'summary.md').write_text(md)
 print(json.dumps(summary,sort_keys=True))
if __name__=='__main__':main()
