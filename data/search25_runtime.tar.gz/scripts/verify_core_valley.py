#!/usr/bin/env python3
from __future__ import annotations
import argparse,json
from fractions import Fraction
from pathlib import Path

def cross(a,b):return (a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0])
def sub(a,b):return tuple(a[i]-b[i] for i in range(3))
def vertices(r):
 if 'vertices_q' in r:return [tuple(Fraction(str(x)) for x in p) for p in r['vertices_q']]
 if 'vertices2' in r:
  s=int(r.get('coordinate_scale',2));return [tuple(Fraction(int(x),s) for x in p) for p in r['vertices2']]
 return [tuple(Fraction(str(x)) for x in p) for p in r['vertices']]
def segmask(a,b):
 v=sub(b,a);n=sum(x*x for x in v)
 if not n:raise ValueError('zero link')
 m=0;i=0
 for x in range(4):
  for y in range(4):
   for z in range(4):
    w=sub((Fraction(x),Fraction(y),Fraction(z)),a);c=cross(w,v);d=sum(w[j]*v[j] for j in range(3))
    if c==(0,0,0) and 0<=d<=n:m|=1<<i
    i+=1
 return m
def check(r,mincov):
 v=vertices(r)
 if len(v)!=23:raise ValueError('vertices !=23')
 m=0
 for a,b in zip(v,v[1:]):m|=segmask(a,b)
 cov=m.bit_count()
 if cov<mincov:raise ValueError(f'coverage {cov} < {mincov}')
 if int(r.get('links',22))!=22:raise ValueError('links !=22')
 if 'covered_count' in r and int(r['covered_count'])!=cov:raise ValueError('stored coverage mismatch')
 miss=[(i//16,(i//4)%4,i%4) for i in range(64) if not(m>>i)&1]
 if 'missing' in r and sorted(map(tuple,r['missing']))!=miss:raise ValueError('missing mismatch')
 return cov
def main():
 ap=argparse.ArgumentParser();ap.add_argument('path',type=Path);ap.add_argument('--jsonl',action='store_true');ap.add_argument('--min-covered',type=int,default=0);a=ap.parse_args()
 rows=[json.loads(s) for s in a.path.read_text().splitlines() if s.strip()] if a.jsonl else [json.loads(a.path.read_text())]
 vals=[check(r,a.min_covered) for r in rows]
 print(json.dumps({'schema':'search25-primary-verification-v1','rows':len(rows),'min':min(vals) if vals else None,'max':max(vals) if vals else None}))
if __name__=='__main__':main()
