#!/usr/bin/env python3
from __future__ import annotations
import argparse,json
from fractions import Fraction
from pathlib import Path

def verts(r):
 raw=r.get('vertices_q') or r.get('vertices')
 if raw is not None:return [tuple(Fraction(str(x)) for x in p) for p in raw]
 s=int(r.get('coordinate_scale',2));return [tuple(Fraction(int(x),s) for x in p) for p in r['vertices2']]
def incidence_and_parameter(p,a,b):
 d=[b[i]-a[i] for i in range(3)];axis=next((i for i,x in enumerate(d) if x),None)
 if axis is None:return False
 t=(p[axis]-a[axis])/d[axis]
 return 0<=t<=1 and all(a[i]+t*d[i]==p[i] for i in range(3))
def check(r,mincov):
 v=verts(r)
 if len(v)!=23 or any(a==b for a,b in zip(v,v[1:])):raise ValueError('invalid path')
 covered=[]
 for x in range(4):
  for y in range(4):
   for z in range(4):
    p=(Fraction(x),Fraction(y),Fraction(z))
    if any(incidence_and_parameter(p,a,b) for a,b in zip(v,v[1:])):covered.append((x,y,z))
 cov=len(covered)
 if cov<mincov:raise ValueError(f'coverage {cov}')
 if int(r.get('covered_count',cov))!=cov:raise ValueError('metadata mismatch')
 if sorted(map(tuple,r.get('missing',[])))!=sorted((x,y,z) for x in range(4) for y in range(4) for z in range(4) if (x,y,z) not in set(covered)):raise ValueError('missing mismatch')
 return cov
def main():
 ap=argparse.ArgumentParser();ap.add_argument('path',type=Path);ap.add_argument('--jsonl',action='store_true');ap.add_argument('--min-covered',type=int,default=0);a=ap.parse_args()
 rows=[json.loads(s) for s in a.path.read_text().splitlines() if s.strip()] if a.jsonl else [json.loads(a.path.read_text())]
 vals=[check(r,a.min_covered) for r in rows]
 print(json.dumps({'schema':'search25-independent-verification-v1','rows':len(rows),'min':min(vals) if vals else None,'max':max(vals) if vals else None}))
if __name__=='__main__':main()
