#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,shutil,subprocess,sys
from pathlib import Path

def run(cmd,**kw):
 print('+',' '.join(map(str,cmd)),flush=True);subprocess.run(list(map(str,cmd)),check=True,**kw)
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--repo',type=Path,default=Path('.'));ap.add_argument('--bundle',type=Path,required=True);ap.add_argument('--workdir',type=Path,required=True);ap.add_argument('--seconds-per-mode',type=int,default=1);ap.add_argument('--allow-mini',action='store_true');a=ap.parse_args();repo=a.repo.resolve();work=a.workdir.resolve();shutil.rmtree(work,ignore_errors=True);work.mkdir(parents=True)
 prepared=work/'prepared';frontier=repo/'runs/2026-07-13-smart-search-23-core-transplant-full/best_candidate.json'
 if not frontier.exists(): raise SystemExit(f'missing required frontier candidate: {frontier}')
 cmd=[sys.executable,repo/'scripts/materialize_search25_inputs.py','--bundle',a.bundle,'--outdir',prepared,'--frontier',frontier]
 if a.allow_mini:cmd.append('--allow-mini')
 run(cmd)
 binary=work/'core_valley_search';run(['g++','-std=c++20','-O3','-pthread',repo/'src/search25/core_valley_search.cpp','-o',binary])
 allout=work/'all';allout.mkdir();verify_shards={0,6,11,15,18,19}
 for shard in range(20):
  out=work/f'shard-{shard}';out.mkdir();cap=120 if shard==0 else 5
  run([binary,'--seeds',prepared/'search25_seeds.tsv','--core',prepared/'common17.tsv','--frontier',prepared/'frontier.tsv','--outdir',out,'--seconds',a.seconds_per_mode,'--workers',1,'--seed',20260725,'--shard',shard,'--shards',20,'--state-cap',cap,'--hamiltonian-state-cap',2,'--top-diverse',5,'--checkpoint-seconds',1])
  for p in out.iterdir():shutil.copy2(p,allout/p.name)
  if shard in verify_shards:
   run([sys.executable,repo/'scripts/verify_core_valley.py',out/f'best_trail_{shard}.json','--min-covered','62'])
   run([sys.executable,repo/'scripts/verify_core_valley_independent.py',out/f'best_trail_{shard}.json','--min-covered','62'])
 stats=[json.loads((work/f'shard-{s}'/f'search_stats_{s}.json').read_text()) for s in range(20)]
 if not all(r['paired_mutations']>0 for r in stats[:19]):raise SystemExit('a primary mode made no paired mutations')
 if min(r['min_common17_overlap'] for r in stats[:19])>15:raise SystemExit('no core overlap <=15 reached')
 if max(r['attempts_per_second'] for r in stats)<100:raise SystemExit('C++ throughput unexpectedly low')
 run([sys.executable,repo/'scripts/build_core_valley_summary.py','--input',allout,'--out',allout,'--expected-shards','20','--strict'])
 if (repo/'scripts/check_long_run_budget.py').exists():run([sys.executable,repo/'scripts/check_long_run_budget.py','--search-seconds','20400','--timeout-minutes','359','--minimum-headroom-seconds','900'])
 report={'schema':'search25-preflight-v1','modes':20,'representative_dual_verified_shards':sorted(verify_shards),'min_common17_overlap':min(r['min_common17_overlap'] for r in stats),'max_attempts_per_second':max(r['attempts_per_second'] for r in stats),'aggregate_best':json.loads((allout/'run_summary.json').read_text())['best_covered'],'dual_verification':True}
 (work/'preflight_report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,sort_keys=True))
if __name__=='__main__':main()
