#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, os, subprocess, sys
from pathlib import Path

def run(cmd, **kw):
    print('+', ' '.join(map(str,cmd)), flush=True)
    subprocess.run(list(map(str,cmd)), check=True, **kw)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--profile',choices=['smoke','full'],required=True)
    ap.add_argument('--shard',type=int,required=True)
    ap.add_argument('--prepared',type=Path,default=Path('prepared-search25'))
    ap.add_argument('--outdir',type=Path,default=Path('results/core_valley'))
    a=ap.parse_args(); a.outdir.mkdir(parents=True,exist_ok=True)
    seconds=180 if a.profile=='smoke' else 20400
    state_cap=5_000_000 if a.profile=='smoke' else 500_000_000
    ham_cap=2_000 if a.profile=='smoke' else 20_000
    diverse=120 if a.profile=='smoke' else 200
    checkpoint=60 if a.profile=='smoke' else 600
    run(['sha256sum','-c','SHA256SUMS'], cwd=a.prepared)
    binary=a.prepared/'core_valley_search'; binary.chmod(0o755)
    raw=a.outdir/f'resource_usage_raw_{a.shard}.txt'
    cmd=['/usr/bin/time','-v','-o',raw,binary,
         '--seeds',a.prepared/'search25_seeds.tsv','--core',a.prepared/'common17.tsv',
         '--frontier',a.prepared/'frontier.tsv','--outdir',a.outdir,
         '--seconds',seconds,'--workers',4,'--seed',20260725,'--shard',a.shard,'--shards',20,
         '--state-cap',state_cap,'--hamiltonian-state-cap',ham_cap,'--top-diverse',diverse,
         '--checkpoint-seconds',checkpoint]
    run(cmd)
    best=a.outdir/f'best_trail_{a.shard}.json'
    saved=a.outdir/f'verified_62plus_{a.shard}.jsonl'
    valley=a.outdir/f'corebroken_valley_{a.shard}.jsonl'
    for verifier in ['scripts/verify_core_valley.py','scripts/verify_core_valley_independent.py']:
        run([sys.executable,verifier,best,'--min-covered',62])
        run([sys.executable,verifier,saved,'--jsonl','--min-covered',62])
        run([sys.executable,verifier,valley,'--jsonl','--min-covered',59])
    stats=a.outdir/f'search_stats_{a.shard}.json'
    if Path('scripts/build_resource_usage.py').exists():
        run([sys.executable,'scripts/build_resource_usage.py','--raw',raw,'--stats',stats,
             '--out',a.outdir/f'resource_usage_{a.shard}.json'])
    report={'schema':'search25-job-report-v1','profile':a.profile,'shard':a.shard,
            'search_outcome':'success','verify_outcome':'success','stats_present':stats.exists(),
            'checkpoint_present':(a.outdir/f'checkpoint_{a.shard}.json').exists()}
    (a.outdir/f'job_report_{a.shard}.json').write_text(json.dumps(report,indent=2)+'\n')
if __name__=='__main__': main()
