#include <algorithm>
#include <array>
#include <atomic>
#include <boost/rational.hpp>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <mutex>
#include <numeric>
#include <optional>
#include <random>
#include <set>
#include <sstream>
#include <stdexcept>
#include <string>
#include <thread>
#include <tuple>
#include <unordered_map>
#include <unordered_set>
#include <utility>
#include <vector>

using Rat = boost::rational<long long>;
using Clock = std::chrono::steady_clock;

struct IPoint { long long x{},y{},z{}; };
struct RPoint { Rat x{},y{},z{}; };
struct Line {
    long long dx{},dy{},dz{},cx{},cy{},cz{};
    bool operator==(const Line&o)const{return std::tie(dx,dy,dz,cx,cy,cz)==std::tie(o.dx,o.dy,o.dz,o.cx,o.cy,o.cz);}
    bool operator<(const Line&o)const{return std::tie(dx,dy,dz,cx,cy,cz)<std::tie(o.dx,o.dy,o.dz,o.cx,o.cy,o.cz);}
};
struct LineHash { size_t operator()(const Line&l)const noexcept{size_t h=1469598103934665603ULL;for(long long v:{l.dx,l.dy,l.dz,l.cx,l.cy,l.cz}){h^=std::hash<long long>{}(v);h*=1099511628211ULL;}return h;} };

static long long gcd_all(std::initializer_list<long long> xs){long long g=0;for(auto x:xs)g=std::gcd(g,std::llabs(x));return g?g:1;}
static Line canonical(Line l){
    long long g=gcd_all({l.dx,l.dy,l.dz,l.cx,l.cy,l.cz});
    l.dx/=g;l.dy/=g;l.dz/=g;l.cx/=g;l.cy/=g;l.cz/=g;
    long long first=0;for(long long v:{l.dx,l.dy,l.dz,l.cx,l.cy,l.cz})if(v){first=v;break;}
    if(first<0){l.dx=-l.dx;l.dy=-l.dy;l.dz=-l.dz;l.cx=-l.cx;l.cy=-l.cy;l.cz=-l.cz;}
    return l;
}
static IPoint crossi(const IPoint&a,const IPoint&b){return {a.y*b.z-a.z*b.y,a.z*b.x-a.x*b.z,a.x*b.y-a.y*b.x};}
static RPoint crossr(const RPoint&a,const RPoint&b){return {a.y*b.z-a.z*b.y,a.z*b.x-a.x*b.z,a.x*b.y-a.y*b.x};}
static RPoint sub(const RPoint&a,const RPoint&b){return {a.x-b.x,a.y-b.y,a.z-b.z};}
static RPoint add(const RPoint&a,const RPoint&b){return {a.x+b.x,a.y+b.y,a.z+b.z};}
static RPoint mul(const RPoint&a,const Rat&t){return {a.x*t,a.y*t,a.z*t};}
static bool eq(const RPoint&a,const RPoint&b){return a.x==b.x&&a.y==b.y&&a.z==b.z;}
static RPoint from_i(const IPoint&p){return {Rat(p.x),Rat(p.y),Rat(p.z)};}

static Line line_from_integer(const IPoint&a,const IPoint&b){
    IPoint d{b.x-a.x,b.y-a.y,b.z-a.z}; if(d.x==0&&d.y==0&&d.z==0)throw std::runtime_error("zero line");
    IPoint c=crossi(a,d); return canonical({d.x,d.y,d.z,c.x,c.y,c.z});
}
static long long lcmll(long long a,long long b){return std::lcm(std::llabs(a),std::llabs(b));}
static Line line_from_rational(const RPoint&a,const RPoint&b){
    RPoint dr=sub(b,a); if(dr.x==0&&dr.y==0&&dr.z==0)throw std::runtime_error("zero rational line");
    long long L=1;for(const Rat&r:{dr.x,dr.y,dr.z})L=lcmll(L,r.denominator());
    IPoint d{dr.x.numerator()*(L/dr.x.denominator()),dr.y.numerator()*(L/dr.y.denominator()),dr.z.numerator()*(L/dr.z.denominator())};
    RPoint dd{Rat(d.x),Rat(d.y),Rat(d.z)}; RPoint c=crossr(a,dd);
    long long C=1;for(const Rat&r:{c.x,c.y,c.z})C=lcmll(C,r.denominator());
    // Scale direction and moment together so all Pluecker coordinates are integral.
    Line l{d.x*C,d.y*C,d.z*C,c.x.numerator()*(C/c.x.denominator()),c.y.numerator()*(C/c.y.denominator()),c.z.numerator()*(C/c.z.denominator())};
    return canonical(l);
}
static bool on_line(const IPoint&p,const Line&l){
    __int128 x=(__int128)p.y*l.dz-(__int128)p.z*l.dy;
    __int128 y=(__int128)p.z*l.dx-(__int128)p.x*l.dz;
    __int128 z=(__int128)p.x*l.dy-(__int128)p.y*l.dx;
    return x==l.cx&&y==l.cy&&z==l.cz;
}
static uint64_t line_mask(const Line&l){uint64_t m=0;int i=0;for(int x=0;x<4;++x)for(int y=0;y<4;++y)for(int z=0;z<4;++z,++i)if(on_line({2*x,2*y,2*z},l))m|=1ULL<<i;return m;}
static RPoint foot(const Line&l){
    // d x c = |d|^2 p_perp for c=p x d.
    IPoint d{l.dx,l.dy,l.dz},c{l.cx,l.cy,l.cz}; IPoint dc=crossi(d,c);
    long long n=l.dx*l.dx+l.dy*l.dy+l.dz*l.dz;
    return {Rat(dc.x,n),Rat(dc.y,n),Rat(dc.z,n)};
}
static std::optional<RPoint> intersection(const Line&a,const Line&b){
    IPoint ca=crossi({a.dx,a.dy,a.dz},{b.dx,b.dy,b.dz});
    if(ca.x==0&&ca.y==0&&ca.z==0)return std::nullopt;
    RPoint p=foot(a),q=foot(b),delta=sub(q,p);
    long long da[3]={a.dx,a.dy,a.dz}, db[3]={b.dx,b.dy,b.dz}; Rat de[3]={delta.x,delta.y,delta.z};
    for(int i=0;i<3;++i)for(int j=i+1;j<3;++j){
        long long det=da[j]*db[i]-da[i]*db[j]; if(!det)continue;
        Rat t=(de[i]*(-db[j])-de[j]*(-db[i]))/Rat(det);
        Rat s=(Rat(da[i])*de[j]-Rat(da[j])*de[i])/Rat(det);
        RPoint x=add(p,{t*a.dx,t*a.dy,t*a.dz}); RPoint y=add(q,{s*b.dx,s*b.dy,s*b.dz});
        if(eq(x,y))return x;
    }
    return std::nullopt;
}
static uint64_t segment_mask(const RPoint&a,const RPoint&b){
    RPoint v=sub(b,a);Rat n=v.x*v.x+v.y*v.y+v.z*v.z;if(n==0)return 0;
    uint64_t m=0;int idx=0;
    for(int x=0;x<4;++x)for(int y=0;y<4;++y)for(int z=0;z<4;++z,++idx){
        RPoint w{sub(from_i({2*x,2*y,2*z}),a)};RPoint cr=crossr(w,v);Rat dot=w.x*v.x+w.y*v.y+w.z*v.z;
        if(cr.x==0&&cr.y==0&&cr.z==0&&dot>=0&&dot<=n)m|=1ULL<<idx;
    }
    return m;
}
static int grid_index(int x,int y,int z){return (x*4+y)*4+z;}
static IPoint grid_point(int idx){int x=idx/16,y=(idx/4)%4,z=idx%4;return {2*x,2*y,2*z};}

struct Seed{std::string kind,id;int covered{};uint64_t missing{};std::vector<Line> lines;};
struct Trail {int covered{};uint64_t mask{};std::vector<RPoint> vertices;std::vector<Line> order;std::string mode,parent,operation;int common_overlap{};uint64_t attempt{};};
struct Options{std::string seeds,core,frontier,outdir;int seconds=180,workers=4,shard=0,shards=20;uint64_t seed=20260725,state_cap=2000000,ham_cap=20000;int top_diverse=120,checkpoint=60;};

static std::vector<std::string> split(const std::string&s,char d){std::vector<std::string>v;std::string x;std::istringstream in(s);while(std::getline(in,x,d))v.push_back(x);return v;}
static Rat parse_rat(const std::string&s){auto p=s.find('/');if(p==std::string::npos)return Rat(std::stoll(s));return Rat(std::stoll(s.substr(0,p)),std::stoll(s.substr(p+1)));}
static Line parse_line(const std::string&s){auto f=split(s,',');if(f.size()!=6)throw std::runtime_error("bad line");return canonical({std::stoll(f[0]),std::stoll(f[1]),std::stoll(f[2]),std::stoll(f[3]),std::stoll(f[4]),std::stoll(f[5])});}
static std::vector<Seed> load_seeds(const std::string&path){
    std::ifstream in(path);if(!in)throw std::runtime_error("cannot open seeds");std::vector<Seed> out;std::string s;
    while(std::getline(in,s)){if(s.empty())continue;auto f=split(s,'\t');if(f.size()!=5)throw std::runtime_error("bad seeds tsv");Seed r;r.kind=f[0];r.id=f[1];r.covered=std::stoi(f[2]);for(auto x:split(f[3],','))if(!x.empty())r.missing|=1ULL<<std::stoi(x);for(auto x:split(f[4],';'))r.lines.push_back(parse_line(x));if(r.lines.size()!=22)throw std::runtime_error("seed lines !=22");out.push_back(std::move(r));}
    return out;
}
static std::unordered_set<Line,LineHash> load_core(const std::string&path){std::ifstream in(path);if(!in)throw std::runtime_error("cannot open core");std::unordered_set<Line,LineHash>o;std::string s;while(std::getline(in,s))if(!s.empty())o.insert(parse_line(s));return o;}
static Trail load_frontier(const std::string&path,const std::unordered_set<Line,LineHash>&core){
    std::ifstream in(path);std::string s;std::getline(in,s);Trail t;t.mode="baseline_control";t.parent="search23-frontier";t.operation="none";
    for(auto ps:split(s,';')){auto q=split(ps,',');if(q.size()!=3)throw std::runtime_error("bad frontier");t.vertices.push_back({parse_rat(q[0])*2,parse_rat(q[1])*2,parse_rat(q[2])*2});}
    if(t.vertices.size()!=23)throw std::runtime_error("frontier !=23 vertices");
    for(size_t i=0;i+1<t.vertices.size();++i){t.mask|=segment_mask(t.vertices[i],t.vertices[i+1]);t.order.push_back(line_from_rational(t.vertices[i],t.vertices[i+1]));}
    t.covered=__builtin_popcountll(t.mask);for(auto&l:t.order)if(core.count(l))++t.common_overlap;return t;
}
static int common_overlap(const std::vector<Line>&ls,const std::unordered_set<Line,LineHash>&core){int n=0;for(auto&l:ls)if(core.count(l))++n;return n;}
static uint64_t infinite_mask(const std::vector<Line>&ls){uint64_t m=0;for(auto&l:ls)m|=line_mask(l);return m;}

struct Graph {std::array<uint32_t,22> adj{};std::array<std::array<std::optional<RPoint>,22>,22> ip;};
static bool connected(const Graph&g){uint32_t seen=1,q=1;while(q){int v=__builtin_ctz(q);q&=q-1;uint32_t n=g.adj[v]&~seen;seen|=n;q|=n;}return __builtin_popcount(seen)==22;}
static int components_without(const Graph&g,int rem){uint32_t avail=((1u<<22)-1)&~(1u<<rem);int c=0;while(avail){++c;uint32_t q=avail&-avail;avail^=q;while(q){int v=__builtin_ctz(q);q&=q-1;uint32_t n=g.adj[v]&avail;avail^=n;q|=n;}}return c;}
static std::optional<Graph> build_graph(const std::vector<Line>&ls){Graph g;for(int i=0;i<22;++i)for(int j=i+1;j<22;++j){auto p=intersection(ls[i],ls[j]);if(p){g.ip[i][j]=g.ip[j][i]=p;g.adj[i]|=1u<<j;g.adj[j]|=1u<<i;}}
    if(!connected(g))return std::nullopt;int leaves=0;for(int i=0;i<22;++i){int d=__builtin_popcount(g.adj[i]);if(!d)return std::nullopt;if(d==1)++leaves;if(components_without(g,i)>2)return std::nullopt;}if(leaves>2)return std::nullopt;return g;}

static std::array<RPoint,2> endpoint_options(const Line&l,const RPoint&contact){
    int axis=l.dx?0:(l.dy?1:2);long long dv=axis==0?l.dx:(axis==1?l.dy:l.dz);std::optional<Rat> mn,mx;
    for(int i=0;i<64;++i){IPoint gp=grid_point(i);if(!on_line(gp,l))continue;Rat gv=axis==0?Rat(gp.x):(axis==1?Rat(gp.y):Rat(gp.z));Rat cv=axis==0?contact.x:(axis==1?contact.y:contact.z);Rat t=(gv-cv)/Rat(dv);if(!mn||t<*mn)mn=t;if(!mx||t>*mx)mx=t;}
    Rat lo=mn?*mn-Rat(1):Rat(-1), hi=mx?*mx+Rat(1):Rat(1);RPoint d{Rat(l.dx),Rat(l.dy),Rat(l.dz)};return {add(contact,mul(d,lo)),add(contact,mul(d,hi))};
}
static Trail realize(const std::vector<Line>&ls,const Graph&g,const std::array<int,22>&path,const std::unordered_set<Line,LineHash>&core,const std::string&mode,const std::string&parent,const std::string&op,uint64_t attempt){
    std::array<RPoint,21> joins;for(int i=0;i<21;++i)joins[i]=*g.ip[path[i]][path[i+1]];
    uint64_t internal=0;for(int i=1;i<21;++i)internal|=segment_mask(joins[i-1],joins[i]);
    auto A=endpoint_options(ls[path[0]],joins[0]);auto B=endpoint_options(ls[path[21]],joins[20]);Trail best;best.covered=-1;
    for(auto&a:A)for(auto&b:B){uint64_t m=internal|segment_mask(a,joins[0])|segment_mask(joins[20],b);int cov=__builtin_popcountll(m);if(cov>best.covered){best.covered=cov;best.mask=m;best.vertices.clear();best.vertices.push_back(a);for(auto&q:joins)best.vertices.push_back(q);best.vertices.push_back(b);best.order.clear();for(int i:path)best.order.push_back(ls[i]);}}
    best.mode=mode;best.parent=parent;best.operation=op;best.common_overlap=common_overlap(best.order,core);best.attempt=attempt;return best;
}
struct HResult{Trail best;bool any=false;uint64_t paths=0;};
static HResult solve_orders(const std::vector<Line>&ls,const Graph&g,const std::unordered_set<Line,LineHash>&core,const std::string&mode,const std::string&parent,const std::string&op,uint64_t attempt,uint64_t cap){
    HResult hr;hr.best.covered=-1;std::array<int,22> path{};std::array<char,22>used{};std::vector<int> starts;for(int i=0;i<22;++i)starts.push_back(i);std::sort(starts.begin(),starts.end(),[&](int a,int b){return __builtin_popcount(g.adj[a])<__builtin_popcount(g.adj[b]);});
    std::function<void(int)> dfs=[&](int depth){if(hr.paths>=cap)return;if(depth==22){++hr.paths;Trail t=realize(ls,g,path,core,mode,parent,op,attempt);if(!hr.any||t.covered>hr.best.covered){hr.any=true;hr.best=std::move(t);}return;}int last=path[depth-1];uint32_t opts=g.adj[last];for(int i=0;i<22;++i)if(used[i])opts&=~(1u<<i);std::vector<int> v;while(opts){int x=__builtin_ctz(opts);opts&=opts-1;v.push_back(x);}std::sort(v.begin(),v.end(),[&](int a,int b){return __builtin_popcount(g.adj[a])<__builtin_popcount(g.adj[b]);});for(int x:v){used[x]=1;path[depth]=x;dfs(depth+1);used[x]=0;if(hr.paths>=cap)return;}};
    int leaf=-1,leafs=0;for(int i=0;i<22;++i)if(__builtin_popcount(g.adj[i])==1){leaf=i;++leafs;}if(leafs==1||leafs==2)starts={leaf};
    for(int s:starts){used.fill(0);used[s]=1;path[0]=s;dfs(1);if(hr.paths>=cap)break;}return hr;
}

static std::vector<Line> make_catalog(const std::vector<Seed>&seeds){std::set<Line>s;for(int i=0;i<64;++i)for(int j=i+1;j<64;++j)s.insert(line_from_integer(grid_point(i),grid_point(j)));for(auto&r:seeds)for(auto&l:r.lines)s.insert(l);return {s.begin(),s.end()};}
static std::string mode_name(int shard){if(shard<=5)return "core-rich-pair";if(shard<=10)return "core-rich-contact";if(shard<=14)return "core-contact-pair";if(shard<=17)return "valley-beam";if(shard==18)return "plateau-closure-control";return "frontier-throughput-control";}
static std::optional<Line> connector_line(const std::vector<Line>&ret,uint64_t missing,std::mt19937_64&rng,const std::optional<Line>&extra=std::nullopt){
    std::vector<Line> all=ret;if(extra)all.push_back(*extra);std::vector<int> holes;for(int i=0;i<64;++i)if((missing>>i)&1)holes.push_back(i);if(holes.empty())for(int i=0;i<64;++i)holes.push_back(i);
    for(int tries=0;tries<30;++tries){int i=rng()%all.size(),j=rng()%all.size();if(i==j)continue;auto q=intersection(all[i],all[j]);if(!q)continue;RPoint h=from_i(grid_point(holes[rng()%holes.size()]));if(eq(h,*q))continue;try{Line l=line_from_rational(h,*q);long long maxv=0;for(auto v:{l.dx,l.dy,l.dz,l.cx,l.cy,l.cz})maxv=std::max(maxv,std::llabs(v));if(maxv<=1000000)return l;}catch(...){} }
    return std::nullopt;
}
static bool unique22(const std::vector<Line>&ls){return ls.size()==22&&std::set<Line>(ls.begin(),ls.end()).size()==22;}

struct WorkerStats{uint64_t attempts=0,optimistic=0,graph_pass=0,orders=0,realized=0;int min_overlap=99;Trail best;std::vector<Trail>saved,valley;};
struct Shared{std::atomic<bool>stop{false};std::atomic<uint64_t>attempts{0};std::atomic<int>done{0};std::mutex mu;Trail best;bool has=false;};

static WorkerStats run_worker(int wid,const Options&o,const std::vector<Seed>&seeds,const std::vector<Line>&catalog,const std::vector<std::vector<int>>&through,const std::unordered_set<Line,LineHash>&core,const Trail&baseline,Shared&shared,Clock::time_point deadline){
    WorkerStats ws;ws.best=baseline;uint64_t flushed_attempts=0;std::mt19937_64 rng(o.seed+o.shard*1000003ULL+wid*10007ULL);std::string mode=mode_name(o.shard);
    std::vector<int> eligible;for(int i=0;i<(int)seeds.size();++i){if(o.shard>=15&&o.shard<=17){if(seeds[i].kind=="valley")eligible.push_back(i);}else if(o.shard==18){if(seeds[i].kind=="plateau")eligible.push_back(i);}else eligible.push_back(i);}if(eligible.empty())for(int i=0;i<(int)seeds.size();++i)eligible.push_back(i);
    while(Clock::now()<deadline&&!shared.stop.load()&&ws.attempts<o.state_cap){++ws.attempts;const Seed&seed=seeds[eligible[rng()%eligible.size()]];std::vector<Line> ls=seed.lines;
        std::vector<int> corepos;for(int i=0;i<22;++i)if(core.count(ls[i]))corepos.push_back(i);int r1,r2;
        if(o.shard==19){if(ws.attempts>1000)break;r1=rng()%22;r2=(r1+1+rng()%21)%22;}
        else {r1=!corepos.empty()?corepos[rng()%corepos.size()]:rng()%22;r2=rng()%22;while(r2==r1)r2=rng()%22;}
        if(r1>r2)std::swap(r1,r2);std::vector<Line> ret;for(int i=0;i<22;++i)if(i!=r1&&i!=r2)ret.push_back(ls[i]);
        std::vector<int> holes;for(int i=0;i<64;++i)if((seed.missing>>i)&1)holes.push_back(i);if(holes.empty())holes.push_back(rng()%64);
        Line a,b;bool ok=false;std::string op;
        for(int tries=0;tries<40&&!ok;++tries){
            int family=o.shard;
            if(family<=5||family==18||family==19){auto&va=through[holes[rng()%holes.size()]];a=va.empty()?catalog[rng()%catalog.size()]:catalog[va[rng()%va.size()]];auto&vb=through[holes[rng()%holes.size()]];b=vb.empty()?catalog[rng()%catalog.size()]:catalog[vb[rng()%vb.size()]];op="atomic_core_rich_pair";}
            else if(family<=10){auto&va=through[holes[rng()%holes.size()]];a=va.empty()?catalog[rng()%catalog.size()]:catalog[va[rng()%va.size()]];auto c=connector_line(ret,seed.missing,rng,a);if(!c)continue;b=*c;op="atomic_core_rich_contact";}
            else if(family<=14){auto c1=connector_line(ret,seed.missing,rng);if(!c1)continue;a=*c1;auto c2=connector_line(ret,seed.missing,rng,a);if(!c2)continue;b=*c2;op="atomic_core_contact_pair";}
            else {if(rng()%2){auto&va=through[holes[rng()%holes.size()]];a=va.empty()?catalog[rng()%catalog.size()]:catalog[va[rng()%va.size()]];}else{auto c=connector_line(ret,seed.missing,rng);if(!c)continue;a=*c;}if(rng()%2)b=catalog[rng()%catalog.size()];else{auto c=connector_line(ret,seed.missing,rng,a);if(!c)continue;b=*c;}op="atomic_valley_pair";}
            std::vector<Line> test=ret;test.push_back(a);test.push_back(b);if(unique22(test)){ls=std::move(test);ok=true;}
        }
        if(!ok)continue;uint64_t im=infinite_mask(ls);int infcov=__builtin_popcountll(im);if(infcov<59)continue;++ws.optimistic;int ov=common_overlap(ls,core);ws.min_overlap=std::min(ws.min_overlap,ov);
        auto gg=build_graph(ls);if(!gg)continue;++ws.graph_pass;auto hr=solve_orders(ls,*gg,core,mode,seed.kind+":"+seed.id,op,ws.attempts,o.ham_cap);ws.orders+=hr.paths;if(!hr.any)continue;++ws.realized;Trail t=std::move(hr.best);
        if(t.covered>ws.best.covered||(t.covered==ws.best.covered&&t.common_overlap<ws.best.common_overlap))ws.best=t;
        if(t.covered>=62){ws.saved.push_back(t);if(ws.saved.size()>size_t(o.top_diverse*3)){std::sort(ws.saved.begin(),ws.saved.end(),[](const Trail&a,const Trail&b){if(a.covered!=b.covered)return a.covered>b.covered;return a.common_overlap<b.common_overlap;});ws.saved.resize(o.top_diverse);}}
        if(t.covered>=59&&t.covered<=61&&t.common_overlap<=15){ws.valley.push_back(t);if(ws.valley.size()>size_t(o.top_diverse*3))ws.valley.resize(o.top_diverse);}
        if(t.covered==64)shared.stop.store(true);if(ws.attempts-flushed_attempts>=4096){shared.attempts.fetch_add(ws.attempts-flushed_attempts);flushed_attempts=ws.attempts;}
    }
    shared.attempts.fetch_add(ws.attempts-flushed_attempts);{std::lock_guard<std::mutex>lk(shared.mu);if(!shared.has||ws.best.covered>shared.best.covered||(ws.best.covered==shared.best.covered&&ws.best.common_overlap<shared.best.common_overlap)){shared.best=ws.best;shared.has=true;}}return ws;
}
static std::string rs(const Rat&r){if(r.denominator()==1)return std::to_string(r.numerator());return std::to_string(r.numerator())+"/"+std::to_string(r.denominator());}
static void write_lines(std::ostream&o,const std::vector<Line>&ls){o<<"[";for(size_t i=0;i<ls.size();++i){if(i)o<<",";auto&l=ls[i];o<<"["<<l.dx<<","<<l.dy<<","<<l.dz<<","<<l.cx<<","<<l.cy<<","<<l.cz<<"]";}o<<"]";}
static void write_trail(std::ostream&o,const Trail&t,int shard){o<<"{";o<<"\"schema\":\"search25-core-valley-trail-v1\",\"candidate_id\":\"mlct22-cv-"<<std::hex<<std::hash<std::string>{}(t.parent+t.operation+std::to_string(t.attempt))<<std::dec<<"\",";o<<"\"covered_count\":"<<t.covered<<",\"links\":22,\"vertices_count\":23,\"missing\":[";bool first=true;for(int i=0;i<64;++i)if(!((t.mask>>i)&1)){if(!first)o<<",";first=false;auto p=grid_point(i);o<<"["<<p.x/2<<","<<p.y/2<<","<<p.z/2<<"]";}o<<"],";o<<"\"mode\":\""<<t.mode<<"\",\"operation\":\""<<t.operation<<"\",\"parent\":\""<<t.parent<<"\",\"source_shard\":"<<shard<<",\"common17_overlap\":"<<t.common_overlap<<",\"attempt_when_found\":"<<t.attempt<<",\"vertices_q\":[";for(size_t i=0;i<t.vertices.size();++i){if(i)o<<",";o<<"[\""<<rs(t.vertices[i].x/2)<<"\",\""<<rs(t.vertices[i].y/2)<<"\",\""<<rs(t.vertices[i].z/2)<<"\"]";}o<<"],\"supporting_line_keys\":";write_lines(o,t.order);o<<"}";}
static void write_jsonl(const std::string&p,const std::vector<Trail>&v,int shard){std::ofstream o(p);std::set<std::string>seen;for(auto&t:v){std::ostringstream k;k<<t.covered<<":"<<t.mask<<":"<<t.common_overlap<<":"<<t.parent<<":"<<t.operation;if(seen.insert(k.str()).second){write_trail(o,t,shard);o<<"\n";}}}
static void ensure_dir(const std::string&p){std::string c="mkdir -p '"+p+"'";if(std::system(c.c_str()))throw std::runtime_error("mkdir failed");}
static Options parse_args(int argc,char**argv){Options o;auto need=[&](int&i){if(i+1>=argc)throw std::runtime_error("missing arg");return std::string(argv[++i]);};for(int i=1;i<argc;++i){std::string a=argv[i];if(a=="--seeds")o.seeds=need(i);else if(a=="--core")o.core=need(i);else if(a=="--frontier")o.frontier=need(i);else if(a=="--outdir")o.outdir=need(i);else if(a=="--seconds")o.seconds=std::stoi(need(i));else if(a=="--workers")o.workers=std::stoi(need(i));else if(a=="--shard")o.shard=std::stoi(need(i));else if(a=="--shards")o.shards=std::stoi(need(i));else if(a=="--seed")o.seed=std::stoull(need(i));else if(a=="--state-cap")o.state_cap=std::stoull(need(i));else if(a=="--hamiltonian-state-cap")o.ham_cap=std::stoull(need(i));else if(a=="--top-diverse")o.top_diverse=std::stoi(need(i));else if(a=="--checkpoint-seconds")o.checkpoint=std::stoi(need(i));else throw std::runtime_error("unknown "+a);}return o;}
int main(int argc,char**argv){try{Options o=parse_args(argc,argv);ensure_dir(o.outdir);auto seeds=load_seeds(o.seeds);auto core=load_core(o.core);Trail baseline=load_frontier(o.frontier,core);if(baseline.covered!=62)throw std::runtime_error("baseline not 62");auto catalog=make_catalog(seeds);std::vector<std::vector<int>>through(64);for(int j=0;j<(int)catalog.size();++j)for(int i=0;i<64;++i)if(on_line(grid_point(i),catalog[j]))through[i].push_back(j);
    Shared shared;shared.best=baseline;shared.has=true;auto start=Clock::now(),deadline=start+std::chrono::seconds(o.seconds);std::vector<WorkerStats> wr(o.workers);std::vector<std::thread>ts;for(int w=0;w<o.workers;++w)ts.emplace_back([&,w]{wr[w]=run_worker(w,o,seeds,catalog,through,core,baseline,shared,deadline);shared.done.fetch_add(1);});auto next_checkpoint=start+std::chrono::seconds(o.checkpoint);while(shared.done.load()<o.workers){std::this_thread::sleep_for(std::chrono::seconds(1));auto now=Clock::now();if(now>=next_checkpoint){Trail snap;{std::lock_guard<std::mutex>lk(shared.mu);snap=shared.best;}std::string tmp=o.outdir+"/checkpoint_"+std::to_string(o.shard)+".json.tmp";std::ofstream f(tmp);f<<"{\"schema\":\"search25-checkpoint-v1\",\"shard\":"<<o.shard<<",\"elapsed_seconds\":"<<std::chrono::duration<double>(now-start).count()<<",\"attempts\":"<<shared.attempts.load()<<",\"best_covered\":"<<snap.covered<<"}\n";f.close();std::rename(tmp.c_str(),(o.outdir+"/checkpoint_"+std::to_string(o.shard)+".json").c_str());next_checkpoint=now+std::chrono::seconds(o.checkpoint);}}for(auto&t:ts)t.join();double elapsed=std::chrono::duration<double>(Clock::now()-start).count();Trail best=shared.has?shared.best:baseline;std::vector<Trail>saved,valley;uint64_t attempts=0,opt=0,gp=0,orders=0,real=0;int minov=99;for(auto&w:wr){attempts+=w.attempts;opt+=w.optimistic;gp+=w.graph_pass;orders+=w.orders;real+=w.realized;minov=std::min(minov,w.min_overlap);saved.insert(saved.end(),w.saved.begin(),w.saved.end());valley.insert(valley.end(),w.valley.begin(),w.valley.end());}
    {std::ofstream f(o.outdir+"/best_trail_"+std::to_string(o.shard)+".json");write_trail(f,best,o.shard);f<<"\n";}write_jsonl(o.outdir+"/verified_62plus_"+std::to_string(o.shard)+".jsonl",saved,o.shard);write_jsonl(o.outdir+"/corebroken_valley_"+std::to_string(o.shard)+".jsonl",valley,o.shard);
    {std::ofstream f(o.outdir+"/paired_diagnostics_"+std::to_string(o.shard)+".json");f<<"{\"schema\":\"search25-paired-diagnostics-v1\",\"shard\":"<<o.shard<<",\"mode\":\""<<mode_name(o.shard)<<"\",\"attempts\":"<<attempts<<",\"optimistic_59plus\":"<<opt<<",\"graph_pass\":"<<gp<<",\"hamiltonian_paths\":"<<orders<<",\"finite_realizations\":"<<real<<",\"min_common17_overlap\":"<<(minov==99?17:minov)<<"}\n";}
    {std::ofstream f(o.outdir+"/search_stats_"+std::to_string(o.shard)+".json");f<<"{\"schema\":\"search25-search-stats-v1\",\"shard\":"<<o.shard<<",\"mode\":\""<<mode_name(o.shard)<<"\",\"elapsed_seconds\":"<<elapsed<<",\"attempts\":"<<attempts<<",\"attempts_per_second\":"<<(elapsed?attempts/elapsed:0)<<",\"best_covered\":"<<best.covered<<",\"best_common17_overlap\":"<<best.common_overlap<<",\"min_common17_overlap\":"<<(minov==99?17:minov)<<",\"paired_mutations\":"<<attempts<<",\"optimistic_59plus\":"<<opt<<",\"graph_pass\":"<<gp<<",\"hamiltonian_paths\":"<<orders<<",\"finite_realizations\":"<<real<<",\"saved_62plus\":"<<saved.size()<<",\"saved_valley\":"<<valley.size()<<"}\n";}
    {std::ofstream f(o.outdir+"/checkpoint_"+std::to_string(o.shard)+".json");f<<"{\"schema\":\"search25-checkpoint-v1\",\"shard\":"<<o.shard<<",\"elapsed_seconds\":"<<elapsed<<",\"attempts\":"<<attempts<<",\"best_covered\":"<<best.covered<<"}\n";}
    {std::ofstream f(o.outdir+"/mode_manifest_"+std::to_string(o.shard)+".json");f<<"{\"schema\":\"search25-mode-manifest-v1\",\"shard\":"<<o.shard<<",\"mode\":\""<<mode_name(o.shard)<<"\",\"workers\":"<<o.workers<<",\"seconds\":"<<o.seconds<<",\"catalog_lines\":"<<catalog.size()<<",\"seed_rows\":"<<seeds.size()<<",\"atomic_two_line_mutation\":true,\"finite_contact_span_scoring\":true}\n";}
    std::cout<<"shard="<<o.shard<<" mode="<<mode_name(o.shard)<<" attempts="<<attempts<<" best="<<best.covered<<" min_core="<<(minov==99?17:minov)<<" aps="<<(elapsed?attempts/elapsed:0)<<"\n";return 0;
}catch(const std::exception&e){std::cerr<<"error: "<<e.what()<<"\n";return 2;}}
